<?php // Code within app\Helpers\Helper.php

namespace App\Helpers;

use Config;
use Illuminate\Support\Str;

class DataBaseHelpers
{
    public static function marketData($formArray = [])
    {
        return [
            [
                'label'=>'',
                'value'=>1
            ],
            [
                'label'=>'',
                'value'=>2
            ]
            [
                'label'=>'',
                'value'=>3
            ]
            [
                'label'=>'',
                'value'=>4
            ]
            [
                'label'=>'',
                'value'=>5
            ]
            [
                'label'=>'',
                'value'=>6
            ]
            [
                'label'=>'',
                'value'=>7
            ]
            [
                'label'=>'',
                'value'=>8
            ]
        ];
    }

}
