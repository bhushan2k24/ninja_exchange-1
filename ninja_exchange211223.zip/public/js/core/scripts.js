/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!****************************************!*\
  !*** ./resources/assets/js/scripts.js ***!
  \****************************************/
(function (window, undefined) {
  'use strict';

  /*
  NOTE:
  ------
  PLACE HERE YOUR OWN JAVASCRIPT CODE IF NEEDED
  WE WILL RELEASE FUTURE UPDATES SO IN ORDER TO NOT OVERWRITE YOUR JAVASCRIPT CODE PLEASE CONSIDER WRITING YOUR SCRIPT HERE.  */
})(window);
/******/ })();

function getInitials(name) {
  const words = name.split(' ');
  if (words.length === 1) {
    // If there's only one word, take the first two characters
    return name.substring(0, 2).toUpperCase();
  } else {
    // If there are more than one word, take the first character from each of the first two words
    const initials = words.slice(0, 2).map(word => word.charAt(0)).join('');
    return initials.toUpperCase();
  }
}

function getRandomColorState() {
  const colorStates = ['success', 'danger', 'warning', 'info', 'dark', 'primary', 'secondary'];
  const randomIndex = Math.floor(Math.random() * colorStates.length);
  return colorStates[randomIndex];
}

$(document).on('change','.markettoscript',function(){

  var market_id = $(this).val();
  var scriptofmarket = $($(this).attr('script_to'));

  $.ajax({
      type: 'GET',
      url: Base_url + 'settings/getscript',
      data: { market_id: market_id },
      success: function (data) {

          console.log("AJAX Response Data:", data);

          // Clear and populate the "Script" dropdown with fetched data
          var scriptDropdown = scriptofmarket;
          scriptDropdown.empty();

          // Add an empty option as a default
          scriptDropdown.append($('<option>', {
              value: '',
              text: 'Select Script'
          }));

          // Populate the dropdown with fetched script data
          $.each(data.data, function (key, value) {
              scriptDropdown.append($('<option>', {
                  value: value.id, // Assuming 'id' is the script ID in your database
                  text: value.script_name // Assuming 'script_name' is the script name in your database
              }));
          });


      },
      error: function (xhr, status, error) {
          console.error('Error:', error);
      }
  });
});
